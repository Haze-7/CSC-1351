//Hayes Chiasson
//Student ID: 897578538

public class Cake {

	//set members / instance variables
	String flavor; // flavor of the cake
	int tiers; // # of tiers on the cake
	double price; // price of each cake
	/**
	 * Constructs a Cake object e
	 *  @param flavor: flavor of the cake
	 *  @param tiers: # of tiers on the cake
	 *  @param price: The price of a cake
	 */
	public Cake()
	{
		flavor = ""; // sets flavor default
		tiers = 0; // sets # of tiers default
		price = 0; // sets the default price
	}
	/**
	 * Sets the price of each cake
	 * @param cakePrice: The user inserted price of each cake
	 */
	public void setPrice(double cakePrice)
	{
		price = cakePrice; // sets the price of the cake to that of the user input passed in through the explicit parameter
	}
	/**
	 * Prints out the card/ info for each cake and its details
	 */
	public void printCard()
	{
		System.out.printf("A " + tiers + " tier " + flavor + " cake\t\t$%.2f\n\n", price); // prints formatted output
		//note for above: placed 2nd \n to follow with the presentation of the output on the instructions
	}
}
